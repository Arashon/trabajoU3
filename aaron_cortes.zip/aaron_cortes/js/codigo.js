function enviar_formulario() {
    let formulario = document.getElementById('mayus');
    formulario.submit();
}
function mayus(e) {
    e.value = e.value.toUpperCase();
}
const fechaNacimiento=document.getElementById("fechaNacimiento")
const edad=document.getElementById("edad")
window.addEventListener("load",function(){

    fechaNacimiento.addEventListener("change", function(){
            if(this.value){
                edad.innerText="la edad es: ${} años"
            }
})


})

var Fn = {
	// Valida el rut con su cadena completa "XXXXXXXX-X"
	validaRut : function (rutCompleto) {
		rutCompleto = rutCompleto.replace("‐","-");
		if (!/^[0-9]+[-|‐]{1}[0-9kK]{1}$/.test( rutCompleto ))
			return false;
		var tmp 	= rutCompleto.split('-');
		var digv	= tmp[1]; 
		var rut 	= tmp[0];
		if ( digv == 'K' ) digv = 'k' ;
		
		return (Fn.dv(rut) == digv );
	},
	dv : function(T){
		var M=0,S=1;
		for(;T;T=Math.floor(T/10))
			S=(S+T%10*(9-M++%6))%11;
		return S?S-1:'k';
	}
}


$("#btnvalida").click(function(){
	if (Fn.validaRut( $("#txt_rut").val() )){
		$("#msgerror").html("El rut ingresado es válido :D");
	} else {
		$("#msgerror").html("El Rut no es válido :'( ");
	}
});


document.getElementById('email').addEventListener('input', function() {
    campo = event.target;
    valido = document.getElementById('emailOK');
        
    emailRegex = /^[-\w.%+]{1,64}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/i;
    //Se muestra un texto a modo de ejemplo, luego va a ser un icono
    if (emailRegex.test(campo.value)) {
      valido.innerText = "válido";
    } else {
      valido.innerText = "incorrecto";
    }
});

